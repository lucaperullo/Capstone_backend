import { Strategy as SpotifyStrategy } from "passport-spotify";
import { authenticateUser } from "../middlewares/jwt.js";
import UserModel from "../routes/users/schema.js";
import passport from "passport";

passport.use(
  new SpotifyStrategy(
    {
      clientID: process.env.CLIENT_ID,
      clientSecret: process.env.CLIENT_SECRET,
      callbackURL: process.env.REDIRECT_URI,
      passReqToCallback: true,
    },
    async function (accessToken, refreshToken, expires_in, profile, next) {
      console.log({ accessToken, refreshToken, expires_in, profile });
      const newUser = {
        spotifyId: spotiUser.id,
        username: spotiUser.display_name,
        password: spotiUser.id,
        profilePic: spotiUser.images[0].url,
      };
      try {
        let user = await UserModel.findOne({ spotifyId: profile.id });
        if (user) {
          console.log(1);
          const tokens = await authenticateUser(user);
          console.log(2);

          user = user["_doc"];

          console.log(3);
          next(null, { ...user, tokens });
        } else {
          user = new UserModel(newUser);
          await user.save();
          const tokens = await authenticateUser(user);
          user = user["_doc"];
          next(null, { ...user, tokens });
        }
      } catch (error) {
        next(error);
      }
    }
  )
);

passport.serializeUser(function (user, done) {
  done(null, user);
});

passport.deserializeUser(function (id, done) {
  done(err, user);
});
export default passport;
