import passport from "passport";
import { Strategy as SpotifyStrategy } from "passport-spotify";
import { authenticateUser } from "../middlewares/jwt";
import UserModel from "../routes/users/schema.js";

passport.use(
  new SpotifyStrategy(
    {
      clientID: process.env.CLIENT_ID,
      clientSecret: process.env.CLIENT_SECRET,
      callbackURL: process.env.REDIRECT_URI,
    },
    async function (accessToken, refreshToken, expires_in, profile, next) {
      console.log(profile);
      const newUser = {
        spotifyId: spotiUser.id,
        username: spotiUser.display_name,
        password: spotiUser.id,
        profilePic: spotiUser.images[0].url,
      };
      try {
        const user = await UserModel.findOne({ spotifyId: profile.id });
        if (user) {
          const tokens = await authenticateUser(user);
          next(null, { user, tokens });
        } else {
          const createdUser = new UserModel(newUser);
          await createdUser.save();
          const tokens = await authenticateUser(createdUser);
          next(null, { user: createdUser, tokens });
        }
      } catch (error) {
        next(error);
      }
    }
  )
);

export default oauth;
